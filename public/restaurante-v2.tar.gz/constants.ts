
import type { Language, Translations } from './types';
import { FlagDE, FlagEN, FlagES, FlagEU, FlagFR, FlagIT } from './components/icons';

export const languages: Language[] = [
    { code: 'EU', name: 'Euskera', flag: FlagEU },
    { code: 'EN', name: 'English', flag: FlagEN },
    { code: 'FR', name: 'Français', flag: FlagFR },
    { code: 'DE', name: 'Deutsch', flag: FlagDE },
    { code: 'IT', name: 'Italiano', flag: FlagIT },
    { code: 'ES', name: 'Español', flag: FlagES },
];

export const translations: Translations = {
    ES: {
        menuDelDia: "Menú del Día",
        carta: "Carta",
        raciones: "Raciones",
        primerosPlatos: "Primeros",
        segundosPlatos: "Segundos",
        postres: "Postres",
        precioPersona: "Precio por persona",
        infoAlergenos: "Información de Alérgenos",
        mostrarAlergenos: "Mostrar Alérgenos",
        ocultarAlergenos: "Ocultar Alérgenos",
        ivaYDatos: "I.V.A. INCLUIDO • DATOS EN TIEMPO REAL",
        visitarWeb: "VISITAR WEB OFICIAL",
        tipos: { ENTRANTE: "Entrantes", ENSALADA: "Ensaladas", ARROZ: "Arroces", MARISCO: "Mariscos", PESCADO: "Pescados", CARNE: "Carnes", POSTRE: "Postres", PRODUCTO: "Producto", "PARA PICAR": "Para Picar", "DEL MAR": "Del Mar", "DE LA TIERRA": "De la Tierra", ARROCES: "Arroces", HAMBURGUESAS: "Hamburguesas", PIZZAS: "Pizzas", CARNES: "Carnes", PESCADOS: "Pescados", POSTRES: "Postres", "BRASA JOSPER": "Brasa Josper", GUARNICIONES: "Guarniciones", OTROS: "Otros" },
        alergenos: {
            GLUTEN: "Gluten", CRUSTACEOS: "Crustáceos", HUEVOS: "Huevos", PESCADO: "Pescado", 
            CACAHUETES: "Cacahuetes", SOJA: "Soja", LACTEOS: "Lácteos", FRUTOS_CASCARA: "Frutos de cáscara",
            APIO: "Apio", MOSTAZA: "Mostaza", SESAMO: "Sésamo", SULFITOS: "Sulfitos", 
            ALTRAMUCES: "Altramuces", MOLUSCOS: "Moluscos", CALAMARES: "Calamares", MARISCO: "Marisco"
        },
        gestion: {
            panel: "Gestión",
            volver: "Volver",
            anadir: "Añadir",
            precioMenu: "Precio Menú",
            guardar: "Guardar",
            plato: "Plato",
            rol: "Rol",
            precio: "Precio",
            activo: "Activo",
            sinPlatos: "No hay platos activos aquí.",
            actualizar: "Publicar Cambios",
            buscando: "Buscando...",
            traduciendo: "Traduciendo..."
        }
    },
    EU: {
        menuDelDia: "Eguneko Menua",
        carta: "Karta",
        raciones: "Razioak",
        primerosPlatos: "Lehenengoak",
        segundosPlatos: "Bigarrenak",
        postres: "Postreak",
        precioPersona: "Prezioa pertsonako",
        infoAlergenos: "Alergenoen Informazioa",
        mostrarAlergenos: "Alergenoak Erakutsi",
        ocultarAlergenos: "Alergenoak Ezkutatu",
        ivaYDatos: "BEZ BARNE • DATUAK DENBORA ERREALEAN",
        visitarWeb: "WEB OFIZIALA BISITATU",
        tipos: { ENTRANTE: "Hasierakoak", ENSALADA: "Entsaladak", ARROZ: "Arrozak", MARISCO: "Itsaskiak", PESCADO: "Arrainak", CARNE: "Haragiak", POSTRE: "Postreak", PRODUCTO: "Produktua", "PARA PICAR": "Pikatzeko", "DEL MAR": "Itsasokoak", "DE LA TIERRA": "Lurrekoak", ARROCES: "Arrozak", HAMBURGUESAS: "Hanburgesak", PIZZAS: "Pizzak", CARNES: "Okelak", PESCADOS: "Arrainak", POSTRES: "Azkenburukoak", "BRASA JOSPER": "Josper Txingarra", GUARNICIONES: "Hornigaiak", OTROS: "Beste batzuk" },
        alergenos: {
            GLUTEN: "Glutena", CRUSTACEOS: "Krustazeoak", HUEVOS: "Arrautzak", PESCADO: "Arraina", 
            CACAHUETES: "Kakahueteak", SOJA: "Soja", LACTEOS: "Esnekiak", FRUTOS_CASCARA: "Oskoldun fruituak",
            APIO: "Apioa", MOSTAZA: "Ziapea", SESAMO: "Sesamoa", SULFITOS: "Sulfitoak", 
            ALTRAMUCES: "Altramuzak", MOLUSCOS: "Moluskuak", MARISCO: "Itsaskia", CALAMARES: "Txipiroiak"
        }
    },
    EN: {
        menuDelDia: "Daily Menu",
        carta: "Menu",
        raciones: "Tapas",
        primerosPlatos: "Starters",
        segundosPlatos: "Mains",
        postres: "Desserts",
        precioPersona: "Price per person",
        infoAlergenos: "Allergen Information",
        mostrarAlergenos: "Show Allergens",
        ocultarAlergenos: "Hide Allergens",
        ivaYDatos: "V.A.T. INCLUDED • REAL-TIME DATA",
        visitarWeb: "VISIT OFFICIAL WEBSITE",
        tipos: { ENTRANTE: "Starters", ENSALADA: "Salads", ARROZ: "Rice", MARISCO: "Seafood", PESCADO: "Fish", CARNE: "Meats", POSTRE: "Desserts", PRODUCTO: "Snacks", "PARA PICAR": "To Share", "DEL MAR": "From the sea", "DE LA TIERRA": "From the land", ARROCES: "Rice dishes", HAMBURGUESAS: "Hamburgers", PIZZAS: "Pizzas", CARNES: "Meat", PESCADOS: "Fish", POSTRES: "Desserts", "BRASA JOSPER": "Josper Charcoal Grill", GUARNICIONES: "Sides", OTROS: "Others" },
        alergenos: {
            GLUTEN: "Gluten", CRUSTACEOS: "Crustaceans", HUEVOS: "Eggs", PESCADO: "Fish", 
            CACAHUETES: "Peanuts", SOJA: "Soy", LACTEOS: "Dairy", FRUTOS_CASCARA: "Nuts",
            APIO: "Celery", MOSTAZA: "Mustard", SESAMO: "Sesame", SULFITOS: "Sulphites", 
            ALTRAMUCES: "Lupins", MOLUSCOS: "Molluscs", MARISCO: "Seafood", CALAMARES: "Squid"
        }
    },
    FR: {
        menuDelDia: "Menu du Jour",
        carta: "Carte",
        raciones: "Rations",
        primerosPlatos: "Entrées",
        segundosPlatos: "Plats",
        postres: "Desserts",
        precioPersona: "Prix par personne",
        infoAlergenos: "Information Allergènes",
        mostrarAlergenos: "Afficher Allergènes",
        ocultarAlergenos: "Masquer Allergènes",
        ivaYDatos: "T.V.A. INCLUSE • DONNÉES EN TEMPS RÉEL",
        visitarWeb: "VISITER LE SITE WEB OFFICIEL",
        tipos: { ENTRANTE: "Entrées", ENSALADA: "Salades", ARROZ: "Riz", MARISCO: "Fruits de mer", PESCADO: "Poissons", CARNE: "Viandes", POSTRE: "Desserts", PRODUCTO: "À grignoter", "PARA PICAR": "Pour picorer", "DEL MAR": "De la mer", "DE LA TIERRA": "De la terre", ARROCES: "Plats de riz", HAMBURGUESAS: "Hamburgers", PIZZAS: "Pizzas", CARNES: "Viandes", PESCADOS: "Poissons", POSTRES: "Desserts", "BRASA JOSPER": "Grillade Josper", GUARNICIONES: "Accompagnements", OTROS: "Autres" },
        alergenos: {
            GLUTEN: "Gluten", CRUSTACEOS: "Crustacés", HUEVOS: "Œufs", PESCADO: "Poisson", 
            CACAHUETES: "Arachides", SOJA: "Soja", LACTEOS: "Produits laitiers", FRUTOS_CASCARA: "Fruits à coque",
            APIO: "Céleri", MOSTAZA: "Moutarde", SESAMO: "Sésame", SULFITOS: "Sulfites", 
            ALTRAMUCES: "Lupins", MOLUSCOS: "Mollusques", MARISCO: "Fruits de mer", CALAMARES: "Calmars"
        }
    },
    DE: {
        menuDelDia: "Tagesmenü",
        carta: "Speisekarte",
        raciones: "Portionen",
        primerosPlatos: "Vorspeisen",
        segundosPlatos: "Hauptgerichte",
        postres: "Desserts",
        precioPersona: "Preis pro Person",
        infoAlergenos: "Allergieinformationen",
        mostrarAlergenos: "Allergene anzeigen",
        ocultarAlergenos: "Allergene ausblenden",
        ivaYDatos: "MWST. INKLUSIVE • ECHTZEITDATEN",
        visitarWeb: "OFFIZIELLE WEBSITE BESUCHEN",
        tipos: { ENTRANTE: "Vorspeisen", ENSALADA: "Salate", ARROZ: "Reis", MARISCO: "Meeresfrüchte", PESCADO: "Fisch", CARNE: "Fleisch", POSTRE: "Desserts", PRODUCTO: "Produkt", "PARA PICAR": "Für den kleinen Hunger", "DEL MAR": "Aus dem Meer", "DE LA TIERRA": "Vom Land", ARROCES: "Reisgerichte", HAMBURGUESAS: "Hamburger", PIZZAS: "Pizzas", CARNES: "Fleisch", PESCADOS: "Fisch", POSTRES: "Desserts", "BRASA JOSPER": "Josper Holzkohlegrill", GUARNICIONES: "Beilagen", OTROS: "Andere" },
        alergenos: {
            GLUTEN: "Gluten", CRUSTACEOS: "Krebstiere", HUEVOS: "Eier", PESCADO: "Fisch", 
            CACAHUETES: "Erdnüsse", SOJA: "Soja", LACTEOS: "Milchprodukte", FRUTOS_CASCARA: "Schalenfrüchte",
            APIO: "Sellerie", MOSTAZA: "Senf", SESAMO: "Sesam", SULFITOS: "Sulfite", 
            ALTRAMUCES: "Lupinen", MOLUSCOS: "Weichtiere", MARISCO: "Meeresfrüchte", CALAMARES: "Tintenfisch"
        }
    },
    IT: {
        menuDelDia: "Menu del Giorno",
        carta: "Carta",
        raciones: "Porzioni",
        primerosPlatos: "Primi",
        segundosPlatos: "Secondi",
        postres: "Dolci",
        precioPersona: "Prezzo a persona",
        infoAlergenos: "Informazioni Allergeni",
        mostrarAlergenos: "Mostra Allergeni",
        ocultarAlergenos: "Nascondi Allergeni",
        ivaYDatos: "I.V.A. INCLUSA • DATI IN TEMPO REALE",
        visitarWeb: "VISITA IL SITO UFFICIALE",
        tipos: { ENTRANTE: "Antipasti", ENSALADA: "Insalate", ARROZ: "Riso", MARISCO: "Frutti di mare", PESCADO: "Pesce", CARNE: "Carne", POSTRE: "Dolci", PRODUCTO: "Prodotto", "PARA PICAR": "Stuzzichini", "DEL MAR": "Dal mare", "DE LA TIERRA": "Dalla terra", ARROCES: "Piatti di riso", HAMBURGUESAS: "Hamburger", PIZZAS: "Pizze", CARNES: "Carne", PESCADOS: "Pesce", POSTRES: "Dolci", "BRASA JOSPER": "Griglia Josper", GUARNICIONES: "Contorni", OTROS: "Altro" },
        alergenos: {
            GLUTEN: "Glutine", CRUSTACEOS: "Crostacei", HUEVOS: "Uova", PESCADO: "Pesce", 
            CACAHUETES: "Arachidi", SOJA: "Soia", LACTEOS: "Latticini", FRUTOS_CASCARA: "Frutta a guscio",
            APIO: "Sedano", MOSTAZA: "Senape", SESAMO: "Sesamo", SULFITOS: "Solfiti", 
            ALTRAMUCES: "Lupini", MOLUSCOS: "Molluschi", MARISCO: "Frutti di mare", CALAMARES: "Calamari"
        }
    }
};