import os
import zipfile
import tarfile
import shutil

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DEST_PUBLIC = os.path.join(ROOT_DIR, "public", "copia_seguridad")
DEST_BACKUP_DIR = os.path.join(ROOT_DIR, "COPIA_DE_SEGURIDAD_V1_V2")

os.makedirs(DEST_PUBLIC, exist_ok=True)
os.makedirs(DEST_BACKUP_DIR, exist_ok=True)

# Copy the markdown manual to public/copia_seguridad as well
manual_src = os.path.join(DEST_BACKUP_DIR, "MANUAL_Y_REGLAS_COMPLETAS_V1_V2.md")
if os.path.exists(manual_src):
    shutil.copy2(manual_src, os.path.join(DEST_PUBLIC, "MANUAL_Y_REGLAS_COMPLETAS_V1_V2.md"))
    shutil.copy2(manual_src, os.path.join(ROOT_DIR, "BACKUP_DOCUMENTACION_V1_V2.md"))

# Exclude patterns
EXCLUDE_DIRS = {"node_modules", ".git", "dist", "dist-ssr", "coverage", ".vscode", ".idea"}
EXCLUDE_EXTS = {".zip", ".tar.gz", ".tgz", ".local", ".log"}

def should_include(rel_path):
    parts = rel_path.split(os.sep)
    for p in parts:
        if p in EXCLUDE_DIRS:
            return False
    _, ext = os.path.splitext(rel_path)
    if ext in EXCLUDE_EXTS and not rel_path.startswith("public/"):
        return False
    # Avoid recursion of the target archives
    if "copia_completa" in rel_path:
        return False
    return True

zip_filename_public = os.path.join(DEST_PUBLIC, "copia_completa_v1_v2.zip")
tar_filename_public = os.path.join(DEST_PUBLIC, "copia_completa_v1_v2.tar.gz")

print(f"Creating ZIP archive at {zip_filename_public}...")
with zipfile.ZipFile(zip_filename_public, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Modify dirs in-place to avoid walking into excluded dirs
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, ROOT_DIR)
            if should_include(rel_path):
                zipf.write(full_path, rel_path)

print(f"Creating TAR.GZ archive at {tar_filename_public}...")
with tarfile.open(tar_filename_public, "w:gz") as tarf:
    for root, dirs, files in os.walk(ROOT_DIR):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, ROOT_DIR)
            if should_include(rel_path):
                tarf.add(full_path, arcname=rel_path)

# Copy to COPIA_DE_SEGURIDAD_V1_V2
shutil.copy2(zip_filename_public, os.path.join(DEST_BACKUP_DIR, "copia_completa_v1_v2.zip"))
shutil.copy2(tar_filename_public, os.path.join(DEST_BACKUP_DIR, "copia_completa_v1_v2.tar.gz"))

# Create an instructions file
instructions = f"""INSTRUCCIONES PARA DESCARGAR Y USAR LA COPIA DE SEGURIDAD
===========================================================

1. ¿DÓNDE ESTÁ MI COPIA DE SEGURIDAD?
   - En tu carpeta de proyecto: /COPIA_DE_SEGURIDAD_V1_V2/
   - Descarga directa web: /copia_seguridad/copia_completa_v1_v2.zip
   - Descarga directa web (tar.gz): /copia_seguridad/copia_completa_v1_v2.tar.gz

2. ¿QUÉ CONTIENE?
   - Todo el código fuente de la app cliente y del panel de gestión.
   - El diccionario oficial de Kanala Beach (src/data/kanala_dictionary.json).
   - Los 14 alérgenos oficiales según el Reglamento UE 1169/2011 con colores y traducciones en 6 idiomas.
   - Toda la lógica de atenuación de platos descartados (en gris).
   - El selector de idiomas con borde metálico para temas oscuros.
   - El sistema de reordenación táctil con botones Subir/Bajar.
   - La frase reglamentaria de los carteles QR.
   - La configuración de conexión con Firebase Firestore en tiempo real.

3. ¿CÓMO PONERLA EN MARCHA EN TU NUEVO ORDENADOR?
   - Descomprime 'copia_completa_v1_v2.zip'
   - Abre un terminal en la carpeta descomprimida
   - Ejecuta:
       npm install
       npm run dev
   - Abre tu navegador en http://localhost:3000
   
¡Todos los datos de tus restaurantes seguirán conectados a la base de datos Firestore en la nube!
"""

with open(os.path.join(DEST_BACKUP_DIR, "LEEME_INSTRUCCIONES.txt"), "w", encoding="utf-8") as f:
    f.write(instructions)

with open(os.path.join(DEST_PUBLIC, "LEEME_INSTRUCCIONES.txt"), "w", encoding="utf-8") as f:
    f.write(instructions)

print("Backup created successfully!")
