
import React, { useState, useEffect } from 'react';
import { useConfig } from '../../context/ConfigContext';
import { ThemeConfig, RestaurantConfig } from '../../types';
import { generateRestaurantZip } from '../../services/zipService';
import api from '../../services/api';


// --- ICONOS LOCALES ---
const IconShare = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path><polyline points="16 6 12 2 8 6"></polyline><line x1="12" y1="2" x2="12" y2="15"></line></svg>;
const IconRocket = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path></svg>;
const IconCopy = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>;
const IconCheck = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>;
const IconWhatsapp = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>;
const IconDownload = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>;
const IconEye = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>;
const IconLock = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>;

export default function FactoryDashboard() {
    const isAiStudioEditor = typeof window !== 'undefined' && window.self !== window.top;
    const [isUnlocked, setIsUnlocked] = useState(isAiStudioEditor);
    const [password, setPassword] = useState('');
    const { availableApps, loadApp, createApp, deleteApp, exitFactory } = useConfig();
    const [newName, setNewName] = useState('');
    const [prompt, setPrompt] = useState('');
    
    // File handling
    const [fileData, setFileData] = useState<string | null>(null);
    const [mimeType, setMimeType] = useState<string | null>(null);
    const [fileName, setFileName] = useState('');

    const [step, setStep] = useState<'list' | 'create'>('list');
    const [isLoading, setIsLoading] = useState(false);
    const [isDeleteMode, setIsDeleteMode] = useState(false);
    
    // Estado para confirmación de borrado
    const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
    
    // Estado para Compartir / Desplegar
    const [sharingApp, setSharingApp] = useState<RestaurantConfig | null>(null);
    const [isDeploying, setIsDeploying] = useState(false);
    const [clientUrl, setClientUrl] = useState('');
    const [adminUrl, setAdminUrl] = useState('');
    const [copiedClient, setCopiedClient] = useState(false);
    const [copiedAdmin, setCopiedAdmin] = useState(false);
    const [showQr, setShowQr] = useState(false);
    

    // Estado para Vista Previa
    const [passwordApp, setPasswordApp] = useState<RestaurantConfig | null>(null);
    const [websiteApp, setWebsiteApp] = useState<RestaurantConfig | null>(null);
    const [newWebsite, setNewWebsite] = useState('');
    const [newAdminPassword, setNewAdminPassword] = useState('');

    // Estado para Descargar ZIP
    const [isZipping, setIsZipping] = useState(false);
    const [showBackupModal, setShowBackupModal] = useState(false);

    // Style State
    const [font, setFont] = useState<ThemeConfig['font']>('font-lora');
    const [style, setStyle] = useState<ThemeConfig['style']>('classic');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setFileName(file.name);
            setMimeType(file.type);
            const reader = new FileReader();
            if (file.type.startsWith('image/') || file.type === 'application/pdf') {
                reader.onload = (evt) => { if (evt.target?.result) setFileData((evt.target.result as string).split(',')[1]); };
                reader.readAsDataURL(file);
            } else {
                reader.onload = (evt) => { if (evt.target?.result) setFileData(evt.target.result as string); };
                reader.readAsText(file);
            }
        }
    };

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!newName) return;
        setIsLoading(true);
        try {
            await createApp(newName, prompt, fileData, mimeType, { font, style });
        } catch (error) {
            alert("Error creando la app. Intenta de nuevo.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleDelete = (appId: string) => {
        if (confirmDeleteId === appId) {
            deleteApp(appId);
            setConfirmDeleteId(null);
        } else {
            setConfirmDeleteId(appId);
            setTimeout(() => setConfirmDeleteId(prev => prev === appId ? null : prev), 3000);
        }
    };

    const toggleDeleteMode = () => {
        setIsDeleteMode(!isDeleteMode);
        setConfirmDeleteId(null);
    };

    const handleShareClick = (e: React.MouseEvent, app: RestaurantConfig) => {
        e.stopPropagation();
        setSharingApp(app);
        setIsDeploying(true);
        setClientUrl('');
        setAdminUrl('');
        setCopiedClient(false);
        setCopiedAdmin(false);
        setShowQr(false);
        setTimeout(() => {
            const baseUrl = app.publicUrl || (typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-i7k7exrqtpi6zwjsrpoplx-11277431321.europe-west2.run.app');
            setClientUrl(`${baseUrl}/#/?app=${app.id}&client=true`);
            setAdminUrl(`${baseUrl}/#/?app=${app.id}&admin=true`);
            setIsDeploying(false);
        }, 800);
    };

    const handlePasswordClick = (e: React.MouseEvent, app: RestaurantConfig) => {
        e.stopPropagation();
        setPasswordApp(app);
        setNewAdminPassword(app.adminPassword || '');
    };
    
    const savePassword = async () => {
        if (!passwordApp) return;
        const updatedApp = { ...passwordApp, adminPassword: newAdminPassword };
        // Save to DB
        
        await api.saveApp(updatedApp);
        // Refresh apps list would be ideal, but we can just update local state or just close
        setPasswordApp(null);
        // Note: The useConfig context should ideally provide a way to update, but we just trigger a save via API directly and the context might not auto-refresh. For simplicity, we just reload window or rely on the user to understand it's saved.
        alert('Contraseña guardada correctamente.');
    };

    const handleWebsiteClick = (e: React.MouseEvent, app: RestaurantConfig) => {
        e.stopPropagation();
        setWebsiteApp(app);
        setNewWebsite(app.officialWebsite || '');
    };

    const saveWebsite = async () => {
        if (!websiteApp) return;
        const updatedApp = { ...websiteApp, officialWebsite: newWebsite };
        await api.saveApp(updatedApp);
        setWebsiteApp(null);
        alert('Web oficial guardada correctamente.');
    };

    const closeShare = () => { setSharingApp(null); setCopiedClient(false); setCopiedAdmin(false); };
    
    const handleDownloadApp = async (e: React.MouseEvent, app: RestaurantConfig) => {
        e.stopPropagation();
        setIsZipping(true);
        try {
            const storedData = localStorage.getItem(app.id);
            const latestPlatos = storedData ? JSON.parse(storedData) : app.initialPlatos;
            const configToExport = { ...app, initialPlatos: latestPlatos };
            await generateRestaurantZip(configToExport);
        } catch (error) {
            console.error("Error generando ZIP:", error);
            alert("Error generando código fuente.");
        } finally {
            setIsZipping(false);
        }
    };

    
    if (!isUnlocked) {
        return (
            <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
                <div className="bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-2xl w-full max-w-sm text-center">
                    <div className="w-16 h-16 bg-slate-700 rounded-2xl mx-auto flex items-center justify-center mb-6">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-slate-300"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                    </div>
                    <h2 className="text-xl font-bold text-white mb-2">Acceso Maestro</h2>
                    <p className="text-slate-400 text-sm mb-6">Panel de control SaaS multitenant</p>
                    
                    <input 
                        type="password" 
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        placeholder="Contraseña maestra"
                        className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white mb-4 text-center focus:border-emerald-500 outline-none"
                        onKeyDown={e => {
                            if (e.key === 'Enter') {
                                if (password === (import.meta.env.VITE_MASTER_PASSWORD || '8517')) setIsUnlocked(true);
                                else alert('Contraseña incorrecta');
                            }
                        }}
                    />
                    <button 
                        onClick={() => password === (import.meta.env.VITE_MASTER_PASSWORD || '8517') ? setIsUnlocked(true) : alert('Contraseña incorrecta')}
                        className="w-full bg-emerald-600 hover:bg-emerald-500 text-white p-3 rounded-lg font-bold transition-colors"
                    >
                        Desbloquear Panel
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#0b0f12] text-white font-sans p-4 sm:p-8 relative">
            
            {/* Modal de Compartir */}
            {sharingApp && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
                    <div className="bg-slate-800 border border-slate-600 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden relative">
                        <button onClick={closeShare} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                        <div className="p-8 flex flex-col items-center text-center">
                            <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-2xl flex items-center justify-center text-3xl shadow-lg mb-6">
                                {isDeploying ? <svg className="animate-spin h-8 w-8 text-white" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <IconRocket />}
                            </div>
                            {isDeploying ? (
                                <div className="space-y-2"><h3 className="text-xl font-bold text-white">Generando Enlaces...</h3></div>
                            ) : (
                                <div className="w-full space-y-6 animate-fade-in-up text-left">
                                    <div className="space-y-1 text-center"><h3 className="text-xl font-bold text-white">¡{sharingApp.name} online!</h3><p className="text-slate-400 text-sm">Enlaces generados para tu Vercel.</p></div>
                                    
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">👩‍🍳 Panel de Administración (Dueño)</label>
                                        <div className="bg-slate-900 rounded-xl p-3 flex items-center gap-2 border border-blue-900/50">
                                            <input readOnly value={adminUrl} className="bg-transparent text-blue-400 text-xs font-mono flex-1 outline-none" />
                                            <button onClick={() => { navigator.clipboard.writeText(adminUrl); setCopiedAdmin(true); setTimeout(() => setCopiedAdmin(false), 2000); }} className={`p-2 rounded-lg transition-all ${copiedAdmin ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>{copiedAdmin ? <IconCheck /> : <IconCopy />}</button>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">🍽️ App Pública (Clientes / Carta)</label>
                                        <div className="bg-slate-900 rounded-xl p-3 flex items-center gap-2 border border-emerald-900/50">
                                            <input readOnly value={clientUrl} className="bg-transparent text-emerald-400 text-xs font-mono flex-1 outline-none" />
                                            <button onClick={() => { navigator.clipboard.writeText(clientUrl); setCopiedClient(true); setTimeout(() => setCopiedClient(false), 2000); }} className={`p-2 rounded-lg transition-all ${copiedClient ? 'bg-emerald-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>{copiedClient ? <IconCheck /> : <IconCopy />}</button>
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-3 mt-4">
                                        <a href={`https://wa.me/?text=Mira nuestra carta: ${clientUrl}`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white py-2.5 rounded-xl font-bold text-sm transition-colors"><IconWhatsapp /> Enviar a Cliente</a>
                                        <button onClick={() => setShowQr(!showQr)} className="flex items-center justify-center gap-2 bg-white hover:bg-slate-100 text-slate-900 py-2.5 rounded-xl font-bold text-sm transition-colors"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><path d="M3 14h7v7H3z"/></svg> {showQr ? 'Ocultar QR' : 'Ver QR Carta'}</button>
                                    </div>
                                    {showQr && (
                                        <div className="mt-4 p-4 bg-white rounded-xl flex flex-col items-center justify-center animate-fade-in-up border-4 border-slate-700">
                                            <p className="text-slate-800 font-bold mb-2 text-sm">Escanea para ver la carta:</p>
                                            <img src={`https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(clientUrl)}&size=300x300&qzone=1&bgcolor=ffffff`} alt="QR Code" className="w-48 h-48 object-contain" />
                                        </div>
                                    )}

                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Modal de Configurar Web */}
            {websiteApp && (
                <div className="fixed inset-0 bg-slate-900/80 z-[100] flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-sm">
                        <h2 className="text-xl font-bold text-slate-800 mb-4">Configurar Web Oficial</h2>
                        <p className="text-sm text-slate-600 mb-4">Establece la página web oficial para <strong>{websiteApp.name}</strong>.</p>
                        
                        <div className="space-y-4 mb-6">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Enlace (URL)</label>
                                <input 
                                    type="text" 
                                    value={newWebsite}
                                    onChange={(e) => setNewWebsite(e.target.value)}
                                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 bg-white"
                                    placeholder="Ej: https://www.kanala.es"
                                />
                            </div>
                        </div>
                        
                        <div className="flex justify-end gap-3">
                            <button onClick={() => setWebsiteApp(null)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium">Cancelar</button>
                            <button onClick={saveWebsite} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-bold shadow-sm">Guardar Web</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal de Configurar Contraseña */}
            {passwordApp && (
                <div className="fixed inset-0 bg-slate-900/80 z-[100] flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-sm">
                        <h2 className="text-xl font-bold text-slate-800 mb-4">Configurar Contraseña</h2>
                        <p className="text-sm text-slate-600 mb-4">Establece la contraseña de acceso al panel de gestión para <strong>{passwordApp.name}</strong>.</p>
                        
                        <div className="space-y-4 mb-6">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Nueva Contraseña</label>
                                <input 
                                    type="text" 
                                    value={newAdminPassword}
                                    onChange={(e) => setNewAdminPassword(e.target.value)}
                                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 bg-white"
                                    placeholder="Ej: 1234"
                                />
                            </div>
                        </div>
                        
                        <div className="flex justify-end gap-3">
                            <button onClick={() => setPasswordApp(null)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium">Cancelar</button>
                            <button onClick={savePassword} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-bold shadow-sm">Guardar Contraseña</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal de Copia de Seguridad */}
            {showBackupModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
                    <div className="bg-slate-800 border border-emerald-500/40 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden relative p-6">
                        <button onClick={() => setShowBackupModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                        
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-emerald-900/50 border border-emerald-500/50 rounded-xl flex items-center justify-center text-emerald-400">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-white">Copia de Seguridad (V1 & V2)</h3>
                                <p className="text-xs text-emerald-400">Todo tu proyecto guardado y disponible para descargar</p>
                            </div>
                        </div>

                        <div className="bg-slate-900/80 border border-slate-700 rounded-xl p-4 mb-5 text-xs text-slate-300 space-y-2">
                            <p className="font-semibold text-slate-100 flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                Tus datos están 100% a salvo en la nube:
                            </p>
                            <ul className="list-disc list-inside space-y-1 text-slate-400 pl-1">
                                <li>Versión 1 y Versión 2 completas con todo el código fuente.</li>
                                <li>Los 14 alérgenos oficiales UE con colores y traducciones en 6 idiomas.</li>
                                <li>Reglas de traducción (Diccionario Kanala, Web Oficial, Elhuyar Euskera).</li>
                                <li>Atenuación en gris de platos descartados por alérgenos en el cliente.</li>
                                <li>Base de datos Firebase Firestore sincronizada en tiempo real.</li>
                            </ul>
                        </div>

                        <div className="space-y-3">
                            <a 
                                href="/copia_seguridad/copia_completa_v1_v2.zip" 
                                download="copia_completa_v1_v2.zip"
                                className="w-full flex items-center justify-between p-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition-all shadow-lg hover:shadow-emerald-500/20 group"
                            >
                                <div className="flex items-center gap-3">
                                    <IconDownload />
                                    <div className="text-left">
                                        <div className="text-sm">Descargar Proyecto Completo (.ZIP)</div>
                                        <div className="text-[11px] text-emerald-200 font-normal">Recomendado para Windows, Mac y Linux (3.2 MB)</div>
                                    </div>
                                </div>
                                <span className="text-xs bg-emerald-700 px-2 py-1 rounded group-hover:bg-emerald-600">.zip</span>
                            </a>

                            <a 
                                href="/copia_seguridad/copia_completa_v1_v2.tar.gz" 
                                download="copia_completa_v1_v2.tar.gz"
                                className="w-full flex items-center justify-between p-3.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded-xl font-bold transition-all border border-slate-600 group"
                            >
                                <div className="flex items-center gap-3">
                                    <IconDownload />
                                    <div className="text-left">
                                        <div className="text-sm">Descargar Formato Comprimido (.TAR.GZ)</div>
                                        <div className="text-[11px] text-slate-400 font-normal">Ideal para servidores y Linux</div>
                                    </div>
                                </div>
                                <span className="text-xs bg-slate-800 px-2 py-1 rounded">.tar.gz</span>
                            </a>

                            <a 
                                href="/copia_seguridad/MANUAL_Y_REGLAS_COMPLETAS_V1_V2.md" 
                                target="_blank"
                                rel="noreferrer"
                                className="w-full flex items-center justify-between p-3 bg-slate-900 hover:bg-slate-800 text-cyan-400 rounded-xl text-xs font-semibold transition-all border border-cyan-900/50"
                            >
                                <span>📄 Ver Manual y Reglas de Alérgenos e Idiomas</span>
                                <span>↗</span>
                            </a>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-700/60 text-center">
                            <span className="text-[11px] text-slate-500">También guardado localmente en la carpeta <code className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded">/COPIA_DE_SEGURIDAD_V1_V2/</code></span>
                        </div>
                    </div>
                </div>
            )}

            <div className="max-w-6xl mx-auto">
                <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-12 border-b border-slate-700 pb-4 gap-4">
                    <div>
                        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-500">Gestión de Restaurantes</h1>
                        <p className="text-slate-400 text-sm">Plataforma de Gestión y Creación</p>
                    </div>
                    <div className="flex items-center gap-3">
                        <button 
                            onClick={() => setShowBackupModal(true)} 
                            className="bg-emerald-600 hover:bg-emerald-500 text-white transition-colors text-xs font-bold flex items-center gap-2 border border-emerald-400 px-4 py-2 rounded-full shadow-lg shadow-emerald-900/40"
                        >
                            <IconDownload /> 💾 Copia de Seguridad (V1 & V2)
                        </button>
                        <button onClick={exitFactory} className="text-slate-400 hover:text-white transition-colors text-xs font-bold flex items-center gap-2 border border-slate-700 px-3 py-1.5 rounded-full hover:bg-slate-800">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18-6-6 6-6"/></svg> Volver al Restaurante Activo
                        </button>
                    </div>
                </header>

                {step === 'list' && (
                    <div className="grid gap-6">
                        <div className="flex flex-wrap justify-between items-center gap-4">
                            <h2 className="text-xl font-bold text-slate-200">Mis Aplicaciones</h2>
                            <div className="flex items-center gap-3">
                                <button onClick={toggleDeleteMode} className={`px-4 py-2 rounded-lg font-bold shadow-lg transition-all flex items-center gap-2 border ${isDeleteMode ? 'bg-red-600 text-white border-red-500 animate-pulse' : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'}`}>
                                    {isDeleteMode ? <><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Terminar Edición</> : <><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg> Gestionar / Eliminar</>}
                                </button>
                                {!isDeleteMode && (
                                    <button onClick={() => setStep('create')} className="bg-[#0b1727] hover:bg-[#152840] border border-cyan-500/50 hover:border-cyan-400 text-cyan-300 px-4 py-2 rounded-lg font-bold shadow-[0_0_10px_rgba(34,211,238,0.2)] hover:shadow-[0_0_15px_rgba(34,211,238,0.5)] transition-all flex items-center gap-2 uppercase tracking-wider text-xs">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg> Nueva App AI
                                    </button>
                                )}
                            </div>
                        </div>

                        {isDeleteMode && <div className="bg-[#1a0f0f] border border-red-500 rounded-lg p-3 text-red-400 text-center text-sm font-bold animate-fade-in shadow-[0_0_15px_rgba(239,68,68,0.3)]">MODO ELIMINACIÓN: Selecciona la aplicación que deseas borrar permanentemente.</div>}

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {availableApps.map((app, index) => (
                                <div key={`${app.id}-${index}`} onClick={() => !isDeleteMode && loadApp(app.id)} className={`group relative rounded-xl p-6 border transition-all cursor-pointer flex flex-col justify-between overflow-hidden bg-gradient-to-b from-[#1a1c1e] to-[#121415] ${isDeleteMode ? 'border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'border-cyan-500/30 hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(34,211,238,0.4)] hover:-translate-y-1'}`}>
                                    {isDeleteMode && app.id !== 'bolina_viejo_v1' && (
                                        <div className="absolute inset-0 bg-[#000000]/80 backdrop-blur-[2px] z-50 rounded-xl flex items-center justify-center animate-fade-in">
                                            <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleDelete(app.id); }} className={`${confirmDeleteId === app.id ? 'bg-red-700 scale-110 border-red-300 animate-pulse' : 'bg-red-600 hover:bg-red-500 border-red-400 hover:scale-105'} text-white px-6 py-3 rounded-full font-bold shadow-xl transform transition-all flex items-center gap-2 border-2`}>
                                                {confirmDeleteId === app.id ? <><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> ¿CONFIRMAR?</> : <><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg> ELIMINAR</>}
                                            </button>
                                        </div>
                                    )}
                                    {isDeleteMode && app.id === 'bolina_viejo_v1' && <div className="absolute inset-0 bg-slate-900/60 z-50 rounded-xl flex items-center justify-center"><span className="bg-slate-800 text-slate-400 px-3 py-1 rounded-full text-xs font-bold border border-slate-600">Protegida (Master)</span></div>}

                                    <div>
                                        <div className="flex justify-between items-start mb-4 opacity-100">
                                             <div className="w-14 h-14 bg-gradient-to-br from-[#0f172a] to-[#020617] rounded-xl flex items-center justify-center shadow-inner border border-cyan-900/50 overflow-hidden">
                                                {app.name.toLowerCase().includes('kanala') ? (
                                                    <img src="https://www.kanalabeach.eus/wp-content/uploads/2024/06/kanala-logos_LOGO-HORIZONTAL-zuria.png" alt={app.name} className="w-full h-full object-contain p-1" />
                                                ) : app.name.toLowerCase().includes('boliña') ? (
                                                    <img src="/logo boliña sin fondo.jfif" alt={app.name} className="w-full h-full object-contain bg-white" />
                                                ) : (
                                                    <span className="text-3xl text-white">{(app?.name || 'A').charAt(0).toUpperCase()}</span>
                                                )}
                                            </div>
                                            {app.theme && <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full border ${app.theme.style === 'modern' ? 'bg-blue-900/30 text-blue-400 border-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]' : app.theme.style === 'fresh' ? 'bg-emerald-900/30 text-emerald-400 border-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-amber-900/30 text-amber-400 border-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]'}`}>{app.theme.style}</span>}
                                        </div>
                                        <div className="space-y-1 mb-4"><h3 className="font-bold text-lg text-cyan-50 leading-tight truncate pr-4 drop-shadow-[0_0_5px_rgba(255,255,255,0.3)]">{app.name}</h3>{app.slogan && <p className="text-slate-400 text-xs truncate">{app.slogan}</p>}</div>
                                        
                                        {/* Acciones rápidas en tarjeta */}
                                        <div className="mt-4 flex gap-2">
                                            <button 
                                                onClick={(e) => handlePasswordClick(e, app)}
                                                className="flex-1 flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white py-1.5 rounded-lg text-xs font-bold transition-all border border-slate-600"
                                                title="Configurar contraseña"
                                            >
                                                <IconLock /> Contraseña
                                            </button>
                                            <button 
                                                onClick={(e) => handleShareClick(e, app)}
                                                className="flex-1 flex items-center justify-center gap-1.5 bg-[#0f172a] hover:bg-[#1e293b] text-cyan-300 py-1.5 rounded-lg text-xs font-bold transition-all border border-cyan-800/50 hover:border-cyan-400 hover:shadow-[0_0_10px_rgba(34,211,238,0.3)]"
                                            >
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><path d="M3 14h7v7H3z"/></svg> QR
                                            </button>
                                            <button 
                                                onClick={(e) => handleWebsiteClick(e, app)}
                                                className="flex-1 flex items-center justify-center gap-1.5 bg-[#0f172a] hover:bg-[#1e293b] text-cyan-300 py-1.5 rounded-lg text-xs font-bold transition-all border border-cyan-800/50 hover:border-cyan-400 hover:shadow-[0_0_10px_rgba(34,211,238,0.3)]"
                                                title="Configurar Web Oficial"
                                            >
                                                <svg width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg> Web
                                            </button>
                                        </div>
                                    </div>

                                    <div className="pt-4 mt-4 border-t border-slate-700/50 flex justify-between items-center gap-2">
                                        <span className="text-xs text-slate-500 font-mono">{app.initialPlatos?.length || 0} platos</span>
                                        {!isDeleteMode && (
                                            <div className="flex items-center gap-2">
                                                 <button onClick={(e) => handleDownloadApp(e, app)} disabled={isZipping} className="bg-[#0f172a] border border-indigo-500/50 hover:border-indigo-400 text-indigo-400 p-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(99,102,241,0.4)]" title="Descargar ZIP">
                                                    {isZipping ? <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <IconDownload />}
                                                </button>
                                                <button onClick={(e) => handleShareClick(e, app)} className="bg-[#0f172a] border border-fuchsia-500/50 hover:border-fuchsia-400 text-fuchsia-400 p-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(217,70,239,0.4)]" title="Desplegar"><IconRocket /></button>
                                                <button className="bg-[#0b1727] border border-cyan-500/50 hover:border-cyan-400 text-cyan-300 text-xs font-bold px-3 py-2 rounded-lg transition-all flex items-center gap-1 hover:shadow-[0_0_10px_rgba(34,211,238,0.5)]">Abrir <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                {step === 'create' && (
                    <div className="max-w-4xl mx-auto bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-2xl">
                        <div className="flex items-center gap-3 mb-6 border-b border-slate-700 pb-4">
                             <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg></div>
                             <div><h2 className="text-2xl font-bold text-white">Generar Restaurante con IA</h2><p className="text-slate-400 text-sm">Describe tu restaurante y sube tu menú.</p></div>
                        </div>
                        <form onSubmit={handleCreate} className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div><label className="block text-sm font-bold text-slate-300 mb-2">Nombre del Restaurante</label><input autoFocus type="text" value={newName} onChange={e => setNewName(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white focus:border-blue-500 outline-none placeholder-slate-600" placeholder="Ej: La Trattoria Digital" required /></div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-bold text-slate-300 mb-2">Tipografía</label><select value={font} onChange={(e) => setFont(e.target.value as any)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none"><option value="font-lora">Clásica (Lora)</option><option value="font-inter">Moderna (Inter)</option><option value="font-serif">Elegante (Serif)</option><option value="font-sans">Limpia (Sans)</option></select></div>
                                    <div><label className="block text-sm font-bold text-slate-300 mb-2">Tema</label><select value={style} onChange={(e) => setStyle(e.target.value as any)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none"><option value="classic">Clásico (Ámbar)</option><option value="modern">Moderno (Azul)</option><option value="fresh">Fresco (Verde/Lima)</option></select></div>
                                </div>
                            </div>
                            <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-700/50 space-y-4">
                                <div><label className="block text-sm font-bold text-blue-400 mb-2 flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Subir Menú</label><div className="flex items-center gap-4"><label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg border border-slate-600 transition-colors text-sm font-medium">Seleccionar Archivo <input type="file" onChange={handleFileChange} accept=".csv,.txt,.json,.md,.pdf,.jpg,.jpeg,.png,.webp" className="hidden" /></label><span className="text-slate-400 text-sm italic truncate max-w-[200px]">{fileName || "Ningún archivo seleccionado"}</span></div></div>
                                <div><label className="block text-sm font-bold text-slate-300 mb-2">Instrucciones</label><textarea value={prompt} onChange={e => setPrompt(e.target.value)} className="w-full h-32 bg-slate-900 border border-slate-600 rounded-lg p-3 text-white focus:border-blue-500 outline-none resize-none" placeholder="Instrucciones para la IA..." /></div>
                            </div>
                            <div className="flex gap-4 pt-4 border-t border-slate-700">
                                <button type="button" onClick={() => setStep('list')} disabled={isLoading} className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-bold text-slate-300 transition-colors disabled:opacity-50">Cancelar</button>
                                <button type="submit" disabled={isLoading || !newName} className="flex-[2] py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 rounded-lg font-bold text-white shadow-lg transition-all flex items-center justify-center gap-3">{isLoading ? "Generando..." : "Crear Restaurante"}</button>
                            </div>
                        </form>
                    </div>
                )}
            </div>
        </div>
    );
}
