
import React, { useState, useEffect } from 'react';
import { DataProvider } from './context/DataContext';
import { ConfigProvider, useConfig } from './context/ConfigContext';
import ClienteApp from './components/cliente/ClienteApp';
import GestionApp from './components/gestion/GestionApp';
import { ErrorBoundary } from './components/ErrorBoundary';
import FactoryDashboard from './components/factory/FactoryDashboard';

// Iconos para la barra de navegación
const IconUser = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>;
const IconSettings = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>;
const IconHome = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;

const getUrlFlags = () => {
    if (typeof window === 'undefined') return { isAdminUrl: false };
    const searchParams = new URLSearchParams(window.location.search);
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#\/?\??/, ''));
    const isPathGestion = window.location.pathname.toLowerCase().includes('/gestion');
    const isAdminUrl =
        searchParams.get('admin') === 'true' ||
        hashParams.get('admin') === 'true' ||
        window.location.hash === '#admin' ||
        isPathGestion;
    return { isAdminUrl };
};

const MainLayout = () => {
    const { config, isFactoryMode, showMasterPanelButton, enterFactory } = useConfig();
    const [isAdminUrl, setIsAdminUrl] = useState(() => getUrlFlags().isAdminUrl);
    const [isAdminMode, setIsAdminMode] = useState(() => getUrlFlags().isAdminUrl);

    useEffect(() => {
        const handleUrlChange = () => {
            const { isAdminUrl: nextAdmin } = getUrlFlags();
            setIsAdminUrl(nextAdmin);
            setIsAdminMode(nextAdmin);
        };
        window.addEventListener('hashchange', handleUrlChange);
        window.addEventListener('popstate', handleUrlChange);
        return () => {
            window.removeEventListener('hashchange', handleUrlChange);
            window.removeEventListener('popstate', handleUrlChange);
        };
    }, []);
    
    const hasAdminAccess = showMasterPanelButton || isAdminUrl;

    useEffect(() => {
        document.title = `${config.name} - Carta Digital`;
    }, [config]);

    // Apply Fonts and Themes dynamically
    const fontClass = config.theme?.font || 'font-lora';
    const themeStyle = config.theme?.style || 'classic';
    
    // Theme colors mapping
    const themeColors = {
        classic: 'bg-[#FDFBF7] text-slate-800',
        modern: 'bg-slate-50 text-slate-900',
        fresh: 'bg-emerald-50/30 text-emerald-950'
    };

    if (isFactoryMode) {
        return <FactoryDashboard />;
    }

    const isKanala = config.name.toLowerCase().includes('kanala');
    const isBolina = config.name.toLowerCase().includes('boliña') || config.id === 'bolina_viejo_v1';
    const customColors = !isKanala && !isBolina ? config.theme?.customColors : undefined;
    
    return (
        <DataProvider key={config.id}>
            <div
                className={`min-h-screen leading-tight ${fontClass} ${isKanala ? 'bg-black text-white' : themeColors[themeStyle]}`}
                style={customColors ? { backgroundColor: customColors.background, color: customColors.text } : undefined}
            >
            {isKanala && <style>{`body { background-color: black; }`}</style>}
            {customColors && <style>{`body { background-color: ${customColors.background}; }`}</style>}
                {/* Navbar */}
                {hasAdminAccess && (
                    <div className="print:hidden relative z-40 w-full bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm py-2 px-4">
                        <div className="max-w-5xl mx-auto flex items-center justify-between">
                            {showMasterPanelButton ? (
                                <button
                                     onClick={enterFactory}
                                    className="flex items-center gap-2 px-3 py-2 text-slate-500 hover:text-slate-800 font-bold text-xs sm:text-sm transition-all hover:bg-slate-50 rounded-lg group"
                                >
                                    <div className="p-1.5 bg-slate-100 rounded-md group-hover:bg-slate-200 transition-colors">
                                        <IconHome />
                                    </div>
                                    <span className="hidden sm:inline">Panel Principal</span>
                                </button>
                            ) : (
                                <div className="flex-1"></div>
                            )}
                            <div className="flex bg-slate-100 p-1 rounded-full shadow-inner border border-slate-200">
                                <button
                                     onClick={() => setIsAdminMode(false)}
                                     className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 ${
                                        !isAdminMode
                                         ? 'bg-amber-500 text-white shadow-md'
                                         : 'text-slate-400 hover:text-slate-600'
                                    }`}
                                >
                                    <IconUser /> <span className="hidden sm:inline">Cliente (Vista Previa)</span>
                                </button>
                                
                                <button
                                     onClick={() => setIsAdminMode(true)}
                                     className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 ${
                                        isAdminMode
                                         ? 'bg-blue-600 text-white shadow-md'
                                         : 'text-slate-400 hover:text-slate-600'
                                    }`}
                                >
                                    <IconSettings /> <span className="hidden sm:inline">Gestión</span>
                                </button>
                            </div>
                        </div>
                    </div>
                )}
                {isAdminMode ? <ErrorBoundary><GestionApp /></ErrorBoundary> : <ClienteApp />}
            </div>
        </DataProvider>
    );
};

export default function App() {
    return (
        <ConfigProvider>
            <MainLayout />
        </ConfigProvider>
    );
}
